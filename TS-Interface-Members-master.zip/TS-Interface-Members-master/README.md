# TS-Interface-Members
Interface having members
