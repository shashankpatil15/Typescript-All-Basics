# TS-Generics
Generic functions, interfaces and classes
