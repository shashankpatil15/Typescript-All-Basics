# JS-Fetch-Posts
Fetch api in Javascript
