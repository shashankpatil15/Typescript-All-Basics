# TS-Interface-Functions
Interfaces having function prototypes
