# TS-Class
Simple Employee class using TS
