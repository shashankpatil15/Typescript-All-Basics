# JS-Toast
A simple toast notification using settmeout and arrow functions
