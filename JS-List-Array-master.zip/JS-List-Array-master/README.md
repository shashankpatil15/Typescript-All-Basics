# JS-List-Array
Mapping an array in javascript to a list &lt;li>
