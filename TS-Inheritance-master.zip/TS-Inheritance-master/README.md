# TS-Inheritance
Simple inheritance comprising super explicit calls
