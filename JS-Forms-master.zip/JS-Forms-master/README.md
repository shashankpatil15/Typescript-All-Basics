# JS-Forms
Simple form validation using pure javascript
