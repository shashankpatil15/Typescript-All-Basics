# TS-Parameterized-Constructor
Employee class with a parameterized constructor
